<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FacebookApp extends Model
{
    //
}
