<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subscriberr extends Model
{
   protected $guarded = ['id'];
}
