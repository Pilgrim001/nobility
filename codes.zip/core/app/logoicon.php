<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class logoicon extends Model
{
    //
}
