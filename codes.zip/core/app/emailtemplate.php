<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emailtemplate extends Model
{
    //
}
