<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WhoWe extends Model
{
    //
}
