<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeadingSection extends Model
{
    //
}
