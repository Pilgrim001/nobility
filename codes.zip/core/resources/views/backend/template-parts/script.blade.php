<script src="{{asset('/assets/backend/global/plugins/respond.min.js')}}"></script>
<script src="{{asset('/assets/backend/global/plugins/excanvas.min.js')}}"></script>
<!-- BEGIN CORE PLUGINS -->
<script src="{{asset('/assets/backend/global/plugins/bootstrap/js/bootstrap.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/js.cookie.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/jquery.blockui.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/uniform/jquery.uniform.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/lightcase/js/lightcase.js')}}" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="{{asset('/assets/backend/global/plugins/morris/morris.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/morris/raphael-min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/counterup/jquery.waypoints.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/counterup/jquery.counterup.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/jquery.sparkline.min.js')}}" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="{{asset('/assets/backend/global/scripts/app.min.js')}}" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="{{asset('/assets/backend/pages/scripts/dashboard.min.js')}}" type="text/javascript"></script>
<!-- END PAGE LEVEL SCRIPTS -->
<!-- Begin Datatables -->
<script src="{{asset('/assets/backend/global/scripts/datatable.js')}}" type="text/javascript"></script>
<script src="{{asset('assets/backend/global/plugins/datatables/datatables.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/pages/scripts/table-datatables-colreorder.min.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/pages/scripts/bootstrap-select.min.js')}}" type="text/javascript"></script>
<!-- End Datatables -->
<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="{{asset('/assets/backend/layouts/layout/scripts/layout.js')}}" type="text/javascript"></script>
<script src="{{asset('/assets/backend/layouts/layout/scripts/demo.js')}}" type="text/javascript"></script>
<!-- End THEME LAYOUT SCRIPTS -->
<!-- BEGIN Custom SCRIPTS -->
<script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script src="{{asset('/assets/backend/custom/js/sweetalert.min.js')}}"></script>
<script src="{{asset('/assets/backend/custom/js/fontawesome-iconpicker.min.js')}}"></script>
<script src="{{asset('/assets/backend/custom/js/spectrum.js')}}"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<!-- End Custom SCRIPTS -->