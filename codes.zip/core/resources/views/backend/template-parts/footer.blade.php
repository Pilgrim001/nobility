<!-- BEGIN FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner"> {{$footer->heading}}
        </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- END FOOTER -->