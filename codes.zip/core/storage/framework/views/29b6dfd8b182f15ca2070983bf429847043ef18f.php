<?php $__env->startSection('addNewButon'); ?>
    <a class="btn blue btn-outline btn-lg sbold pull-right topModalbtn" href="<?php echo e(route('history')); ?>"> Back </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Edit History'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-body form">
                    <form role="form" action="<?php echo e(route('update.history', $history->id)); ?>" method="post" novalidate enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('put')); ?>

                        <div class="form-body">
                            <div class="form-group form-md-line-input">
                                <label for="form_control_1"><b>Title</b></label>
                                <input type="text" name="history_title" class="form-control" id="history_title" value="<?php echo e($history->title); ?>">
                                <span class="help-block">History title goes here...</span>
                            </div>
                            <div class="form-group">
                                <label for="form_control_1"><b>Description(Maximum 350 Characters)</b></label>
                                <textarea name="history_text" style="width: 100% !important; display: inherit;"
                                          id="history_text" rows="8" maxlength="350"><?php echo e($history->text); ?></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn green btn-block btn-lg">
                                    <i class="fa fa-check"></i> Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>