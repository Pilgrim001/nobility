<title><?php echo e($gset->title); ?></title>
<?php echo $__env->make('backend.template-parts.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class=" login">
<style>
    .farem:before{
        float: left;
        margin: 5px;
    }
</style>
<div class="menu-toggler sidebar-toggler"></div>
<!-- END SIDEBAR TOGGLER BUTTON -->
<!-- BEGIN LOGO -->
<div class="logo">
    <a href="#">
        <img src="../assets/pages/img/logo-big.png" alt=""/> </a>
</div>
<?php if(session()->has('message')): ?>
    <h4 class="text-center"><span class="alert" style="background-color: #3FABA4; color: #fff;"><?php echo e(session()->get('message')); ?></span></h4>
<?php elseif(session()->has('alert')): ?>
    <h4 class="text-center"><span class="alert" style="background-color: red; color: #fff;"><?php echo e(session()->get('alert')); ?></span></h4>
<?php endif; ?>
<!-- END LOGO -->
<!-- BEGIN LOGIN -->
<div class="content">
    <!-- BEGIN LOGIN FORM -->
    <form class="login-form" action="<?php echo e(route('admin.login')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3 class="form-title font-green">Sign In</h3>
        <div class="alert alert-danger display-hide">
        </div>
        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
            <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
            <label class="control-label visible-ie8 visible-ie9">Username</label>
            <input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off"
                   placeholder="Username" name="username"/>
            <?php if($errors->has('username')): ?>
                <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <label class="control-label visible-ie8 visible-ie9">Passord</label>
            <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off"
                   placeholder="Password" name="password"/>
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
            <?php endif; ?>
        </div>
        <div class="form-actions text-center">
            <button type="submit" class="btn btn-block green uppercase">Login</button>
        </div>
        <div class="create-account">
            <p>
                <?php echo e($footer->heading); ?>

            </p>
        </div>
    </form>
    <!-- END LOGIN FORM -->
</div>
<?php echo $__env->make('backend.template-parts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $(document).on('click', '.a-alert', function (e) {
            e.preventDefault();
            $(this).parent().remove();
        }) ;
    });
</script>
</body>