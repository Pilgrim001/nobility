<?php $__env->startSection('addNewButon'); ?>
    <button class="btn green btn-outline btn-lg sbold pull-right topModalbtn" data-toggle="modal"
            data-target="#createpackage"> Add New Package
    </button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Packages List'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet box green-meadow">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-list"></i>Packages List
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body text-center">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover text-center">
                            <thead>
                            <tr>
                                <th class="text-center"> Name</th>
                                <th class="text-center"> Price</th>
                                <th class="text-center"> Validity</th>
                                <th class="text-center"> channels</th>
                                <th class="text-center"> Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gateway_list">
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->price); ?> <?php echo e($general->currency_text); ?></td>
                                    <td><?php echo e($item->validity); ?> Days</td>
                                    <td>
                                        <?php
                                        $i = 1;
                                        $n = count($item->channel);
                                        ?>
                                        <?php $__currentLoopData = $item->channel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b><?php echo e($chan->name); ?> <?php if($n == $i): ?> <?php else: ?> , <?php endif; ?></b>
                                        </span>
                                            <?php
                                            $i++;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <button class="btn purple editpack"
                                                data-toggle="modal" data-route="<?php echo e(route('package.edit',$item->id)); ?>"
                                                data-target="#editpackage"><i class="fa fa-edit"></i>
                                        </button>
                                        <button class="btn red deletepack"
                                                data-toggle="modal" data-id="<?php echo e($item->id); ?>"
                                                data-target="#deletepackage"><i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($items->render()); ?>

                </div>
            </div>
        </div>

        <!-- Begin Modal create Getway -->
        <div class="modal fade" id="createpackage" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                        <h4><b>Create Package</b></h4>
                    </div>
                    <div class="modal-body">
                        <div class="portlet light bordered">
                            <div class="portlet-body form">
                                <form id="add-form" action="<?php echo e(route('package.store')); ?>" method="post"
                                      enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-body">
                                        <div class="form-group">
                                            <label for=""><b>Name</b></label>
                                            <input type="text" name="name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><b>Price</b></label>
                                            <input type="text" name="price" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><b>Validity</b></label>
                                            <input type="text" name="validity" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><b>Details</b></label>
                                            <input type="text" id="details" name="details[]" class="form-control"><a
                                                    href="" class="adddetails"><i
                                                        class="fa fa-plus-circle fa-2x"></i></a>
                                            <div class="content">

                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="single"><b>Channels</b></label>
                                            <select name="channel[]" class="selectpicker form-control" data-live-search="true" multiple>
                                                <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($channel->id); ?>"><?php echo e($channel->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-actions noborder">
                                        <button type="submit" class="btn btn-block btn-lg green"><i
                                                    class="fa fa-check"></i>Submit
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn red" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- End Modal Create Getway -->
        </div>

        <!-- Begin Modal edit Getway -->
        <div class="modal fade" id="editpackage" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                        <h4><b>Edit Package</b></h4>
                    </div>
                    <div class="modal-body">
                        <div class="portlet light bordered">
                            <div class="portlet-body form">
                                <form id="edit-form" method="post" action="<?php echo e(route('package.update')); ?>"
                                      enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" id="pacid" name="id">
                                    <div class="form-body">
                                        <div class="form-group">
                                            <label for=""><b>Name</b></label>
                                            <input type="text" id="e-name" name="name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><b>Price</b></label>
                                            <input type="text" id="e-price" name="price" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><b>Validity</b></label>
                                            <input type="text" id="e-validity" name="validity" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><b>Details</b></label>
                                            <div class="edit-details">

                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="single"><b>Channels</b></label>
                                            <select name="channel[]" class="selectpicker selectorid form-control" data-live-search="true" multiple>
                                                <?php
                                                $iv = 1;
                                                ?>
                                                <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($channel->id); ?>"><?php echo e($channel->name); ?></option>
                                                <?php ($iv++); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-actions noborder">
                                        <button type="submit" class="btn btn-block btn-lg green"><i
                                                    class="fa fa-check"></i>Submit
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn red" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- End Modal Create Getway -->
        </div>
        <!-- End Modal edit Gateway-->
        <!-- Begin Modal Delete Package -->
        <div class="modal fade" id="deletepackage" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                    </div>
                    <div class="modal-body">
                        <div class="portlet light bordered">
                            <div class="portlet-body form">
                                <form role="form" action="<?php echo e(route('package.delete')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-body">
                                        <div class="form-group form-md-line-input text-center">
                                            <h3>Are you Want Delete This Package?</h3>
                                            <input type="hidden" name="itemid" id="packDelId">
                                        </div>
                                    </div>
                                    <div class="form-actions noborder text-center">
                                        <button type="submit" class="btn blue">Yes</button>
                                        <button type="button" class="btn red" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- End Modal Delete Package -->
    </div>
    <script type="text/javascript">
        $(document).ready(function () {
            $(document).on('click', '.adddetails', function (e) {
                e.preventDefault();
                $('<div class="form-group"><label></label><input type="text" class="detailsrem form-control" name="details[]"><a href="" class="remvdetails"><i class="fa fa-minus-circle fa-2x"></i></a><div>').appendTo('.content');
            });

            $(document).on('click', '.remvdetails', function (e) {
                e.preventDefault();
                $(this).parent('div').remove();
            });

            $(document).on('click', '.adddeta', function (e) {
                e.preventDefault();
                $('<div class="form-group"><label></label><input type="text" class="detailsrem form-control" name="details[]"><a href="" class="remvdetails"><i class="fa fa-minus-circle fa-2x"></i></a><div>').appendTo('.edit-details');
            });

            $(document).on('click', '.editpack', function () {
                $('.edit-details').html('')
                var pId = $(this).data('route');
                $.ajax({
                    method: "get",
                    url: pId,
                    data: {
                        'id': $('.editpack').data('id')
                    },
                    success: function (data) {
                        var name = data.name;
                        var price = data.price;
                        var validity = data.validity;
                        var id = data.id;
                        var ch = data.channel;
                        var iv = 1;
                        var cha = [];
                        $.each(ch, function (k,v) {
                            cha.push(v.id);
                            iv++
                        });
                        $('.selectorid').selectpicker('val', cha);

                        $('#e-name').val(name);
                        $('#e-price').val(price);
                        $('#e-validity').val(validity);
                        $('#pacid').val(id);
                        var details = JSON.parse(data.details);
                        var editAdd;
                        $.each(details, function (index, value) {
                            //console.log( index + ": " + value );
                            $('<div><input type="text" value="' + value + '" name="details[]" class="form-control"><a href="" class="editclass remvdetails"><i class="fa fa-minus-circle fa-2x fa-class"></i></a><div class="content form-group"></div>').appendTo('.edit-details');
                            editAdd = $('.remvdetails').length;
                            if (index == 0) {
                                $('.editclass').removeClass("remvdetails").addClass("adddeta");
                                $('.fa-class').removeClass('fa-minus-circle').addClass('fa-plus-circle');
                            }
                        });
                    }
                });
            });
            $(document).ready(function () {
                $(document).on('click', '.deletepack', function () {
                    $('#packDelId').val($(this).data('id'));
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>