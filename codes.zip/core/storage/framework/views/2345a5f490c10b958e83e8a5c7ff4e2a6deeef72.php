
<?php $__env->startSection('addNewButon'); ?>
    <a class="btn green btn-outline btn-lg sbold pull-right topModalbtn" href="<?php echo e(route('user.subs')); ?>"> Send EMail </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Subscriber List'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet box green-meadow">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-list"></i>Subscriber Details
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body text-center">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover text-center">
                            <thead>
                            <tr>
                                <th class="text-center"> Name</th>
                                <th class="text-center"> Email</th>
                                <th class="text-center"> Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gateway_list">
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td>
                                        <a data-id="<?php echo e($item->id); ?>" data-toggle="modal" data-target="#unsubs" class="btn red subsid">
                                            <i class="fa fa-close"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($items->render()); ?>

                </div>
            </div>
            <div class="modal fade" id="unsubs" tabindex="-1" role="basic" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                        </div>
                        <div class="modal-body">
                            <div class="portlet light bordered">
                                <div class="portlet-body form">
                                    <form role="form" action="<?php echo e(route('user.unsubs')); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-body">
                                            <div class="form-group form-md-line-input text-center">
                                                <h3>Do you Want to Unsubscribe This User?</h3>
                                                <input type="hidden" name="id" id="sid">
                                            </div>
                                        </div>
                                        <div class="form-actions noborder text-center">
                                            <button type="submit" class="btn blue">Yes</button>
                                            <button type="button" class="btn red" data-dismiss="modal">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function () {
           $(document).on('click', '.subsid', function () {
             $('#sid').val($(this).data('id'));
           });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>