<?php $__env->startSection('Body'); ?>
    <!--==================================
===== Breadcrumb Section Start ===========
===================================-->
    <section class="breadcrumb-section section-bg-clr5" style="background-image: url('<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->breadcrumb); ?>');">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-content">
                        <h2 class="breadcrumb-color">Blog Single</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--==================================
    ===== Breadcrumb Section End ===========
    ===================================-->

    <!--==================================
    ===== Blog Single Section Start ===========
    ===================================-->
    <section class="blog-single-section section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-single-content details-content">
                        <div class="blog-single-desc">
                            <div class="blog-single-thumb"><img src="<?php echo e(asset('assets/frontend/upload/images/blog')); ?>/<?php echo e($post->image); ?>" alt="blog"></div>
                            <div class="blog-single-header">
                                <h4><?php echo e($post->title); ?></h4>
                            </div>
                            <?php echo $post->body; ?>

                        </div>
                    </div>
                    <div class="fb-comments" data-href="<?php echo e(request()->url()); ?>" data-numposts="5" data-width="755" data-parent="true"></div>
                </div>

                <div class="col-md-4">
                    <aside>
                        <div class="widget widget-categories">
                            <h4>Leatest Posts</h4>
                            <ul>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singlepost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('post', Crypt::encrypt($singlepost->id))); ?>"><?php echo e($singlepost->title); ?></a>
                                </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>
                    </aside>
                </div>
            </div>
            <span id="blog-share"></span>
        </div>
    </section>
    <!--==================================
    ===== Blog Section End ===========
    ===================================-->
    <?php echo $appid->app_id; ?>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#blog-share").jsSocials({
                showLabel: false,
                showCount: false,
                shares: ["email", "twitter", "facebook", "googleplus", "linkedin", "pinterest", "stumbleupon", "whatsapp"]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>