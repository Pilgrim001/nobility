<?php $__env->startSection('addNewButon'); ?>
    <a class="btn blue btn-outline btn-lg sbold pull-right topModalbtn" href="<?php echo e(route('menu.index')); ?>"> Back </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Add New Menu'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="portlet light bordered">
            <div class="portlet-body form">
                <form role="form" action="<?php echo e(route('menu.store')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="form-group form-md-line-input">
                            <label for="form_control_1"><b>Menu Name</b></label>
                            <input type="text" name="page_title" class="form-control"
                                   id="form_control_1" placeholder="Enter Menu Name">
                            <span class="help-block">Your Menu Name goes here...</span>
                        </div>
                        <div class="form-group">
                            <label for="form_control_1"><b>Page Content</b></label>
                            <textarea name="page_content"
                                      style="width: 100% !important; display: inherit;"
                                      id="page_content" rows="15"></textarea>
                        </div>
                    </div>
                    <div class="form-actions noborder">
                        <button type="submit" class="btn btn-block btn-lg green"><i
                                    class="fa fa-check"></i>Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function(){
            bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>