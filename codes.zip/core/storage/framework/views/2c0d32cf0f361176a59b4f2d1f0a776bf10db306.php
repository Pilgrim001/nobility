<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($gset->title); ?></title>
    <!--Favicon add-->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->fav); ?>">
    <?php echo $__env->make('frontend.template-parts.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link href="<?php echo e(asset('assets/frontend/css/color.php?color=')); ?><?php echo e($gset->color); ?>" rel="stylesheet">
    <script>
        $(document).ready(function(){
            $.ajaxSetup({
                'X-CSRF-Token' : "<?php echo e(csrf_token()); ?>"
            })
        });
    </script>
</head>
<body >
<!--preloader start-->
<div class="preloader">
    <ul >
        <li>
            <div class="loader"></div>
            <div class="loading"></div>
        </li>
        <li>
            <div class="loader"></div>
            <div class="loading"></div>
        </li>
        <li>
            <div class="loader"></div>
            <div class="loading"></div>
        </li>
    </ul>
</div>
<!--preloader end-->

<!--==================================
===== Header  Top Start ==============
===================================-->
<?php echo $__env->make('frontend.template-parts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--==================================
===== header Section End ===========
===================================-->

<!--==================================
===== Banner Section End ===========
===================================-->
<?php $__env->startSection('Banner'); ?>
    <?php echo $__env->yieldSection(); ?>
<!--==================================
===== Banner Section End ===========
===================================-->

<?php $__env->startSection('Body'); ?>
    <?php echo $__env->yieldSection(); ?>

<!--==================================
===== Footer Section Start ===========
===================================-->
<?php echo $__env->make('frontend.template-parts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--==================================
===== Footer Section End ===========
===================================-->

<!--==================================
=============== Js File ===========
===================================-->
<?php echo $__env->make('frontend.template-parts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
