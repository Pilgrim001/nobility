<?php $__env->startSection('Body'); ?>
    <!--==================================
===== Breadcrumb Section Start ===========
===================================-->
    <section class="breadcrumb-section section-bg-clr5" style="background-image: url('<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->breadcrumb); ?>');">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-content">
                        <h2 class="breadcrumb-color">Block IO</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--==================================
    ===== Breadcrumb Section End ===========
    ===================================-->
    <section class="blog-section blog-section1 section-padding section-bg-clr">
        <div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-inverse">
                <div class="panel-body">
                    <?php
                        $amount = Session::get('amount');
                        $bcoin = Session::get('bcoin');
                        $sendadd = Session::get('sendadd');
                        $qrurl = Session::get('qrurl');
                    ?>
                    <div  class="col-md-8 col-md-offset-2 text-center">

                        <h1><?php echo $gset->currency_symbol; ?> <?php echo e($amount); ?>

                            <i class="fa fa-exchange"></i> <i class="fa fa-bitcoin"></i> <?php echo e($bcoin); ?></h1>
                        <br><br><br>
                        <h3> PLEASE SEND EXACTLY <span style="color: green"> <?php echo e($bcoin); ?> BTC</span> <br><br>
                            TO <span style="color: green"> <?php echo e($sendadd); ?></span> <br></h3>
                        <br><br>
                        <?php echo $qrurl; ?>

                        <h2 style="font-weight:bold;">SCAN TO SEND</h2>

                        <br><br>
                        <h4 style="color: red;"> ** Minimum 3 confirmations  Required to Credit your account.</h4>
                        <br/>

                    </div>


                </div>
            </div>
        </div>
    </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>