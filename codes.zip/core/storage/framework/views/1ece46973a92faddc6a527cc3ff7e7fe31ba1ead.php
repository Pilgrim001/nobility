<?php $__env->startSection('addNewButon'); ?>
    <a class="btn blue btn-outline btn-lg sbold pull-right topModalbtn" href="<?php echo e(route('cause.index')); ?>"> Back </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Edit Event'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-body form">
                    <form role="form" action="<?php echo e(route('cause.update', $item->id)); ?>" method="post" novalidate enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('put')); ?>

                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_control_1"><b>Title</b></label>
                                        <input type="text" name="title" class="form-control" id="title" value="<?php echo e($item->title); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="logo"><b>Image: (Select jpg/jpeg/png only)</b></label>
                                        <div class="fileinput " data-provides="fileinput">
                                            <div class="input-group select_image">
                                                <div class="form-control" data-trigger="fileinput">
                                                    <i class="fa fa-camera fileinput-exists"></i>&nbsp;
                                                    <span class="fileinput-filename"> </span>
                                                </div>
                                                <span class="input-group-addon btn default btn-file">
                                                                <span class=""> Select file </span>
                                                                <input id="image" type="file" name="image" required> </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="form_control_1"><b>Goal</b></label>
                                <div class="input-group">
                                    <span class="input-group-addon"><?php echo e($gset->currency_symbol); ?></span>
                                    <input type="text" name="goal" class="form-control" id="goal" value="<?php echo e($item->goal); ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="form_control_1"><b>Description</b></label>
                                <textarea name="description" style="width: 100% !important; display: inherit;"
                                          id="description" rows="20" required><?php echo e($item->description); ?></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn green btn-block btn-lg">
                                    <i class="fa fa-check"></i> Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function(){
            bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>