<?php $__env->startSection('Body'); ?>
    <section>
        <?php
            $send_pay = Session::get('Sdata');
        ?>
    <?php echo $send_pay; ?>

    </section>
    <script type="text/javascript">
        $(document).ready(function(){
            $( "body" ).contextmenu(function() {
                alert( "Right Click Not Allow!" );
            });
            $("#pament_form" ).submit();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>