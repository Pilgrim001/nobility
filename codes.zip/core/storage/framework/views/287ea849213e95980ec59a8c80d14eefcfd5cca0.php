<?php $__env->startSection('title', 'User List'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet box green-meadow">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-list"></i>Searched User List
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body text-center">
                    <div class="table-scrollable">
                        <?php if(count($items)): ?>
                        <table class="table table-bordered table-hover text-center">
                            <thead>
                            <tr>
                                <th class="text-center"> Serial</th>
                                <th class="text-center"> Name</th>
                                <th class="text-center"> Username</th>
                                <th class="text-center"> Email</th>
                                <th class="text-center"> Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gateway_list">
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                                    <td><?php echo e($item->username); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('user.edit', $item->id)); ?>"
                                           class="btn green menu_item_edit_btn"><i class="fa fa-eye"></i></a>
                                    </td>
                                </tr>
                                <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                    </table>
                        <?php else: ?>
                                <p class="text-center" style="color: #9d1611">No Data Matched</p>
                        <?php endif; ?>
                    </div>
                    <?php echo e($items->render()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>