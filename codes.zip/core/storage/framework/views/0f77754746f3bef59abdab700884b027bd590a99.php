<!DOCTYPE html>
<html lang="en" class="ie9 no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(isset($gset->title) ? $gset->title : ''); ?></title>
    <!--Favicon add-->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->fav); ?>">
    <?php echo $__env->make('frontend.template-parts.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<!--Preloader start-->
<div class="preloader">
    <div class="spinner">
        <div class="cube1"></div>
        <div class="cube2"></div>
    </div>
</div>
<!--Preloader end-->
<!--Scroll to top start-->
<div class="scroll-to-top">
    <a href=""><i class="fa fa-caret-up"></i></a>
</div><!--Scroll to top end-->
<!--Support Bar Start-->
<div class="support-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-12 support-wrapper">
                <div class="row">
                    <div class="col-md-6">
                        <div class="support-info">
                            <a href="#">
                                <p>
                                    <i class="fa fa-comment"></i> Get Support</p>
                            </a>
                            <p>
                                <i class="fa fa-user"></i> Users: <?php echo e($us); ?> </p>
                        </div>
                    </div>
                    <div class="col-md-6 text-right">
                        <div class="support-info">
                            <p class="phone">
                                <i class="fa fa-phone"></i> <?php echo e(isset($contact->mobile) ? $contact->mobile : ''); ?></p>
                            <p>
                                <i class="fa fa-envelope"></i> <?php echo e(isset($contact->email) ? $contact->email : ''); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Support Bar End-->
<!--mobile logo -->
<div class="mobile-logo">
    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->logo); ?>"
                                     alt="Logo Image Will Be Here"></a>
</div>

<!--main menu start-->
<nav class="main-menu">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="logo">
                    <a href="<?php echo e(route('home')); ?>"><img
                                src="<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->logo); ?>"
                                alt="Logo Image Will Be Here"></a>
                </div>
            </div>
            <div class="col-md-8 text-right">
                <ul id="menu-bar">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('page',$menu->id)); ?>"><?php echo e($menu->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                    <?php if(auth()->guard()->check()): ?>
                        <li><a href="<?php echo e(route('user.dashboard')); ?>">
                                <img alt="" class="img-circle img-responsive"
                                     src="<?php echo e(asset('assets/frontend/upload/images/profile')); ?>/<?php echo e(Auth::user()->image); ?>"
                                     alt="" style="max-width: 20px; max-height: 100px; display: inline-block;"/>
                                <span class="username username-hide-on-mobile">
                    <?php echo e(Auth::user()->username); ?></span>
                            </a></li>
                    <?php else: ?>
                        <li><a href="#">Account <i class="fa fa-caret-down"></i></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav><!--main menu end-->

<?php $__env->startSection('Body'); ?>
<?php echo $__env->yieldSection(); ?>
<!--pament method section start-->
<section class="section-padding payment-method payment-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title text-center">
                    <h2>Channels</h2>
                </div>
            </div>
        </div>
        <div class="row payment-logo">
            <div class="swiper-container client-container">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide text-center" style="color: #fff">
                            <div class="our-client"><img
                                        src="<?php echo e(asset('assets/frontend/upload/images/channels/')); ?>/<?php echo e($channel->image); ?>"
                                        alt="client">
                            </div>
                            <h4><b style="color:#0372ff"><?php echo e($channel->name); ?></b></h4>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
</section><!--pament method section end-->
<!--footer section start-->
<footer class="footer-section section-padding padding-bottom-0 text-center">
    <div class="container">
        <div class="row ">
            <div class="col-md-6 col-md-offset-3">
                <div class="footer-logo">
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->logo); ?>"
                                              alt="Footer Logo"></a>
                </div>
                <p class="footer-text"><?php echo $footer->text; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="footer-social-link">
                    <div class="social-link">
                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($social->link); ?>"><i class="fa <?php echo e($social->icon); ?>"></i></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <?php echo e($footer->heading); ?>

                </div>
            </div>
        </div>
    </div>
</footer><!--footer section end-->
<?php echo $__env->make('frontend.template-parts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $contact->script; ?>

</body>
</html>