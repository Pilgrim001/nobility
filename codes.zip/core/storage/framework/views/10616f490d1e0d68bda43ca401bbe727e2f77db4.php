<!--bootstrap Css-->
<link href="<?php echo e(asset('assets/frontend/css/plugins/bootstrap.min.css')); ?>" rel="stylesheet">
<!--font-awesome Css-->
<link href="<?php echo e(asset('assets/frontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
<!--Swiper  Css-->
<link href="<?php echo e(asset('assets/frontend/css/plugins/swiper.min.css')); ?>" rel="stylesheet">
<!--Lightcase  Css-->
<link href="<?php echo e(asset('assets/frontend/css/plugins/lightcase.css')); ?>" rel="stylesheet">
<!--File input  Css-->
<link href="<?php echo e(asset('/assets/backend/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css')); ?>" rel="stylesheet" type="text/css" />
<!--SweetAlert  Css-->
<link href="<?php echo e(asset('/assets/backend/custom/css/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
<!--JsSocial Css-->
<link href="<?php echo e(asset('assets/frontend/jssocial/jssocials.css')); ?>" media="all" rel="stylesheet" />
<link href="<?php echo e(asset('assets/frontend/jssocial/jssocials-theme-flat.css')); ?>" media="all" rel="stylesheet" />
<!--Style Css-->
<link href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" rel="stylesheet">
<!--jquery script load-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.js')); ?>"></script>