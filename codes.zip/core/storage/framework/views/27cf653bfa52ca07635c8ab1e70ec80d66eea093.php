<?php $__env->startSection('title', 'Our Service Settings'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet light form-fit">
                <div class="portlet-body">
                    <form action="<?php echo e(route('service.store')); ?>" class="form-horizontal form-bordered" method="post"
                          novalidate>
                        <?php echo e(csrf_field()); ?>

                        <div class="form-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="logo"><b>Icon</b></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">fa</span>
                                            <input id="icon" type="text" class="form-control socioicon"
                                                   name="icon"
                                                   placeholder="Click here...">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="title"><b>Title</b></label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-external-link"></i></span>
                                            <input id="title" type="text" class="form-control" name="title"
                                                   placeholder="Your Title..">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="form_control_1"><b>Description</b></label>
                                            <textarea name="text" style="width: 100% !important; display: inherit;"
                                                      id="descirption" rows="10"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group text-center">
                                    <label for="favicon"></label>
                                    <div class="form-actions">
                                        <button type="submit" class="btn green btn-lg btn-block">
                                            <i class="fa fa-check"></i> Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-md-12">
                <div class="portlet box green-meadow">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="fa fa-list"></i>Service List
                        </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th class="text-center"> Icon</th>
                                    <th class="text-center"> Title</th>
                                    <th class="text-center"> Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><i class="fa <?php echo e($service->icon); ?>"></i></td>
                                        <td><?php echo e($service->title); ?></td>
                                        <td>
                                            <button type="button" class="btn purple service-edit-btn"
                                                    data-toggle="modal"
                                                    data-id="<?php echo e($service->id); ?>"
                                                    data-fa="<?php echo e($service->icon); ?>"
                                                    data-title="<?php echo e($service->title); ?>"
                                                    data-text="<?php echo e($service->description); ?>" data-target="#editService">Edit
                                            </button>
                                            <button type="button" class="btn red service-delete-btn"
                                                    data-toggle="modal"
                                                    data-id="<?php echo e($service->id); ?>" data-target="#deleteService">
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!--start Edit Modal-->
    <div class="modal fade" id="editService" tabindex="-1" role="basic" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                    <h3>Edit Service</h3>
                </div>
                <div class="modal-body">
                    <div class="portlet light bordered">
                        <div class="portlet-body form">
                            <form role="form" action="<?php echo e(route('service.edit')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-body">
                                    <div class="form-group">
                                        <input type="hidden" name="serviceid" id="e-serviceid">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="logo"><b>Icon</b></label>
                                                <div class="input-group">
                                                    <span class="input-group-addon">fa</span>
                                                    <input id="eicon" type="text" class="form-control socioicon"
                                                           name="icon"
                                                           placeholder="Click here...">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="title"><b>Title</b></label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-external-link"></i></span>
                                                    <input id="etitle" type="text" class="form-control" name="title"
                                                           placeholder="Your Title..">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="form_control_1"><b>Description</b></label>
                                                    <textarea name="text"
                                                              style="width: 100% !important; display: inherit;"
                                                              id="etext" rows="10"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn green btn-lg btn-block">
                                                <i class="fa fa-check"></i> Update
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn red default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>

        <!-- /.modal-dialog -->
    </div>
    <!--End Edit Modal-->

        <div class="modal fade" id="deleteService" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
    </div>
    <div class="modal-body">
    <div class="portlet light bordered">
    <div class="portlet-body form">
    <form role="form" action="<?php echo e(route('service.delete')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-body">
    <div class="form-group form-md-line-input text-center">
    <h3>Are you Want Delete This Service?</h3>
    <input type="hidden" name="serviceid" id="d-serviceid">
    </div>
    </div>
    <div class="form-actions noborder text-center">
    <button type="submit" class="btn blue">Yes</button>
    <button type="button" class="btn red" data-dismiss="modal">Cancel</button>
    </div>
    </form>
    </div>
    </div>
    </div>
    </div>
    <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
    </div>
    <script type="text/javascript">
        $(document).ready(function () {
            $(document).on('focus', '.socioicon', function () {
                $('.socioicon').iconpicker();
            });

            $(document).on('click', '.service-edit-btn', function () {
                $('#e-serviceid').val($(this).data('id'));
               $('#eicon').val($(this).data('fa'));
               $('#etitle').val($(this).data('title'));
               $('textarea#etext').val($(this).data('text'));
            });
            $(document).on('click', '.service-delete-btn', function () {
            var sId = $(this).data('id');
            $('#d-serviceid').val(sId);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>