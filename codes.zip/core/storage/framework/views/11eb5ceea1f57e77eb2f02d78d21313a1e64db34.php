<?php $__env->startSection('Body'); ?>
    <!--==================================
===== Breadcrumb Section Start ===========
===================================-->
    <section class="breadcrumb-section section-bg-clr5" style="background-image: url('<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->breadcrumb); ?>');">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-content">
                        <h2 class="breadcrumb-color">Latest Blog</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--==================================
    ===== Breadcrumb Section End ===========
    ===================================-->
    <!--==================================
   ===== Blog Section Start ===========
   ===================================-->

    <section class="blog-section blog-section1 section-padding section-bg-clr">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Section Heading Start -->
                    <div class="section-heading">
                        <h2>our <span>latest blogs</span></h2>
                        <span>
                          <img src="<?php echo e(asset('assets/frontend/upload/images/logo/')); ?>/<?php echo e($logo->fav); ?>" alt="icon">
                        </span>
                        <p>
                            <?php echo $section->blog; ?>

                        </p>
                    </div>
                    <!-- Section heading End -->
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6">
                    <!-- Blog List Start -->
                    <div class="blog-list blog-list1">
                        <div class="blog-thumb">
                            <img src="<?php echo e(asset('assets/frontend/upload/images/blog/')); ?>/<?php echo e($blog->image); ?>" alt="blog" style="width: 555px; height: 350px">
                            <div class="blog-overlay">
                            </div>
                            <div class="blog-overlay-icon">
                                <a href="#"><i class="fa fa-link" aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <div class="blog-content">
                            <div class="blog-date">
                                <div class="blog-date1">
                                    <p><?php echo e(date('d', strtotime($blog->created_at))); ?></p>
                                    <p><?php echo e(date('M', strtotime($blog->created_at))); ?></p>
                                    <p><?php echo e(date('y', strtotime($blog->created_at))); ?></p>
                                </div>
                            </div>
                            <div class="blog-text">
                                <h3><a href="<?php echo e(route('post', Crypt::encrypt($blog->id))); ?>"><?php echo e($blog->title); ?></a></h3>
                                <p><?php echo str_limit($blog->body, 250); ?></p>
                                <a href="<?php echo e(route('post', Crypt::encrypt($blog->id))); ?>">read more</a>
                            </div>
                        </div>
                    </div>
                    <!-- Blog List End -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center">
          <?php echo e($blogs->render()); ?>

            </div>
        </div>
    </section>
    <!--==================================
   ===== Blog Section End ===========
   ===================================-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>