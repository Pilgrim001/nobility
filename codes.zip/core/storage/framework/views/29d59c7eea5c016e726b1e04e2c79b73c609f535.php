<!--Bootstrap v3 script load here-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/bootstrap.min.js')); ?>"></script>
<!--Wow script load-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/swiper.min.js')); ?>"></script>
<!--Slick Nav Js File Load-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/lightcase.js')); ?>"></script>
<!--CounterUp script load-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.countdown.min.js')); ?>"></script>
<!--Countdown script load-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.counterup.min.js')); ?>"></script>
<!--Waypoint script load-->
<script src="<?php echo e(asset('assets/frontend/js/plugins/waypoints.min.js')); ?>"></script>
<!--file input script load-->
<script src="<?php echo e(asset('/assets/backend/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js')); ?>" type="text/javascript"></script>
<!--SweetAlert script load-->
<script src="<?php echo e(asset('/assets/backend/custom/js/sweetalert.min.js')); ?>"></script>
<!--jsSocial file load-->
<script src="<?php echo e(asset('assets/frontend/jssocial/jsocial.js')); ?>"></script>
<!--Main js file load-->
<script src="<?php echo e(asset('assets/frontend/js/custom.js')); ?>"></script>