<!DOCTYPE html>
<html lang="en" class="ie9 no-js">
<head>
    <meta charset="utf-8"/>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/assets/frontend/upload/images/logo')); ?>/<?php echo e($logo->fav); ?>" sizes="30x30">
    <title><?php echo e($gset->title); ?></title>
    <?php echo $__env->make('backend.template-parts.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>
        $(document).ready(function(){
            $.ajaxSetup({
                'X-CSRF-Token' : "<?php echo e(csrf_token()); ?>"
            })
        });
    </script>
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
<div class="page-header navbar navbar-fixed-top">
    <div class="page-header-inner ">
        <div class="page-logo">
            <a href="<?php echo e(route('user.dashboard')); ?>">
                <img src="<?php echo e(asset('/assets/frontend/upload/images/logo')); ?>/<?php echo e($logo->logo); ?>" alt="logo" class="logo-default"
                     style="max-width: 100px; max-height: 40PX; margin-top: 4px;"/> </a>
            <div class="menu-toggler sidebar-toggler"></div>
        </div>
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse"
           data-target=".navbar-collapse"> </a>
        <?php echo $__env->make('frontend.template-parts.topmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="pull-right" style="padding: 3px 50px;">
            <span><h4 style="color: ghostwhite"><b style="color: limegreen">Current Balance:</b> <?php echo e(Auth::user()->balance); ?> <?php echo e($gset->currency_symbol); ?></h4></span>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<div class="page-container">
<?php echo $__env->make('frontend.template-parts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <h3 class="page-title uppercase bold"> <?php echo $__env->yieldContent('title'); ?>
                    <?php $__env->startSection('addNewButon'); ?>
                    <?php echo $__env->yieldSection(); ?>
                </h3>
            </div>
            <?php $__env->startSection('body'); ?>
            <?php echo $__env->yieldSection(); ?>
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- END CONTENT -->
</div>
<?php echo $__env->make('backend.template-parts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('backend.template-parts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>