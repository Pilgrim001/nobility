<?php $__env->startSection('title', 'Footer Settings'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-body form">
                    <form role="form" action="<?php echo e(route('footer.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class="form-body">
                                <div class="form-group form-md-line-input">
                                    <label for="form_control_1"><b>Heading</b></label>
                                    <input type="text" name="footer_head" class="form-control" id="footer_head"
                                           value="<?php echo e(isset($item->heading) ? $item->heading : ' '); ?>">
                                    <span class="help-block">Footer Heading goes here...</span>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Text</b></label>
                                    <textarea name="footer_text" style="width: 100% !important; display: inherit;"
                                              id="footer_text" rows="20"><?php echo e(isset($item->text) ? $item->text : ' '); ?></textarea>
                                </div>
                            </div>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn green btn-block btn-lg">
                                    <i class="fa fa-check"></i> Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function(){
            bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>