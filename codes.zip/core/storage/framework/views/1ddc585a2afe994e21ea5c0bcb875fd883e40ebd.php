<?php $__env->startSection('addNewButon'); ?>
    <a class="btn blue btn-outline btn-lg sbold pull-right topModalbtn" href="<?php echo e(route('whowe.index')); ?>"> Back </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Create WhoWe Section'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-body form">
                    <form role="form" action="<?php echo e(route('store.whowe')); ?>" method="post" novalidate enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-body">
                            <div class="form-group">
                            <label for="logo"><b>Icon</b></label>
                            <div class="input-group">
                                <span class="input-group-addon">fa</span>
                                <input id="social_icon" type="text" class="form-control socioicon"
                                       name="social_icon"
                                       placeholder="Click here...">
                            </div>
                            </div>
                            <div class="form-group">
                                <label for="form_control_1"><b>Title</b></label>
                                <input type="text" name="who_title" class="form-control" id="who_title" required>
                            </div>
                            <div class="form-group">
                                <label for="form_control_1"><b>Description(Maximum 300 Characters)</b></label>
                                <textarea name="who_text" style="width: 100% !important; display: inherit;"
                                          id="who_text" rows="8" maxlength="300" required></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn green btn-block btn-lg">
                                    <i class="fa fa-check"></i> Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function () {
            $(document).on('focus', '.socioicon', function () {
                $('.socioicon').iconpicker();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>