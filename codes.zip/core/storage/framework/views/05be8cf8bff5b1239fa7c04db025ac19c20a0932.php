<?php $__env->startSection('title', 'Volunteer Details'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet box green-meadow">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-list"></i>Volunteer Details
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover text-center">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th><?php echo e($item->fname); ?> <?php echo e($item->lname); ?></th>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <th><?php echo e($item->email); ?></th>
                            </tr>
                            <tr>
                                <th>Phone Number</th>
                                <th><?php echo e($item->phone); ?></th>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <th><?php echo e($item->address); ?></th>
                            </tr>
                            <tr>
                                <th>Image</th>
                                <th>
                                    <a id="pending-prove"
                                       href="<?php echo e(asset('assets/frontend/upload/images/volunteer')); ?>/<?php echo e($item->image); ?>"
                                       data-rel="lightcase">
                                        <span id="text"></span>
                                        <img id="prove-img"
                                             src="<?php echo e(asset('assets/frontend/upload/images/volunteer')); ?>/<?php echo e($item->image); ?>"
                                             height="40px" width="80px"/>
                                    </a>
                                </th>
                            <tr>
                            <tr>
                                <th>Profession</th>
                                <th><?php echo e($item->profession); ?></th>
                            </tr>
                            <tr>
                                <th>Facebook Profile</th>
                                <th><a href="<?php echo e($item->fb); ?>" target="_blank"><?php echo e($item->fb); ?></a></th>
                            </tr>
                            <tr>
                                <th>Twitter Profile</th>
                                <th><a href="<?php echo e($item->tw); ?>" target="_blank"><?php echo e($item->tw); ?></a></th>
                            </tr>
                            <tr>
                                <th>Linkedin Profile</th>
                                <th><a href="<?php echo e($item->ln); ?>" target="_blank"><?php echo e($item->ln); ?></a></th>
                            </tr>
                                <th>Description</th>
                                <th><?php echo e($item->description); ?></th>
                            </tr>
                            </tr>
                            </thead>
                        </table>
                    </div>

                    <div class="form-actions noborder text-center">
                        <form action="<?php echo e(route('voluteer.approve', $item->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <button type="submit" class="btn btn-lg green" name="accept" value="1">Accept
                            </button>
                            <button type="submit" class="btn btn-lg red" name="reject" value="2">Reject
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function ($) {
            $('a[data-rel^=lightcase]').lightcase();
            $(document).on('mouseenter', '#pending-prove', function () {
                $('#prove-img').css('opacity', '.09');
                $('#text').text('Click');
            });
            $(document).on('mouseleave', '#pending-prove', function () {
                $('#prove-img').css('opacity', '1');
                $('#text').text('');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>