<?php if(session()->has('message')): ?>
        <script type="text/javascript">
            $(document).ready(function () {
                swal("Success!!", "<?php echo e(session()->get('message')); ?>", "success")
            });
        </script>
<?php endif; ?>

<?php if(session()->has('alert')): ?>
    <script type="text/javascript">
        $(document).ready(function () {
            swal("Failed!!", "<?php echo e(session()->get('alert')); ?>", "warning")
        });
    </script>
<?php endif; ?>