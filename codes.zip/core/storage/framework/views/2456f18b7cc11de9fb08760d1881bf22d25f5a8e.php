<?php $__env->startSection('title', 'Sections Settings'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-body form">
                    <form role="form" action="<?php echo e(route('section.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class="form-body">
                                <div class="form-group">
                                    <label for="form_control_1"><b>Our Causes</b></label>
                                    <textarea class="form-control" name="cause" rows="8"><?php echo e(isset($item->cause) ? $item->cause : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Our Volunteer</b></label>
                                    <textarea class="form-control" name="volunteer" rows="8"><?php echo e(isset($item->volunteer) ? $item->volunteer : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Become Volunteer</b></label>
                                    <textarea class="form-control" name="be_volunteer" rows="8"><?php echo e(isset($item->be_volunteer) ? $item->be_volunteer : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Who Talk About Us</b></label>
                                    <textarea class="form-control" name="who_talk" rows="8"><?php echo e(isset($item->who_talk) ? $item->who_talk : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Upcoming Events</b></label>
                                    <textarea class="form-control" name="event" rows="8"><?php echo e(isset($item->event) ? $item->event : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Latest Blogs</b></label>
                                    <textarea class="form-control" name="blog" rows="8"><?php echo e(isset($item->blog) ? $item->blog : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="form_control_1"><b>Our Sponsors</b></label>
                                    <textarea class="form-control" name="sponsor" rows="8"><?php echo e(isset($item->sponsor) ? $item->sponsor : ''); ?></textarea>
                                </div>
                            </div>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn green btn-block btn-lg">
                                    <i class="fa fa-check"></i> Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>