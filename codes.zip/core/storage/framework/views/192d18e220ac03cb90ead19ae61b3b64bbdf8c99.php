<?php $__env->startSection('title', 'Diposit History'); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('backend.template-parts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.template-parts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row page-bar-btn">
        <div class="col-md-12">
            <div class="portlet box green-meadow">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-list"></i>Diposit Logs
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body text-center">
                    <div class="table-scrollable">
                        <table class="table table-bordered table-hover text-center">
                            <thead>
                            <tr>
                                <th class="text-center">Gateway Name</th>
                                <th class="text-center">Deposit Amount</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gateway_list">
                                    <td>
                                        <?php echo e(isset($item->gateway->name) ? $item->gateway->name : ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->amount); ?> <?php echo e($gset->currency_symbol); ?>

                                    </td>
                                    <td>
                                        <?php if($item->status == 0): ?>
                                            <b style="color: #e67e22"> Pending </b>
                                        <?php elseif($item->status == 1): ?>
                                            <b style="color: #27ae60"> Accepted </b>
                                        <?php elseif($item->status == 2): ?>
                                            <b style="color: #e74c3c"> Rejected </b>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e(($item->created_at->diffForHumans())); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($items->render()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.user-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>